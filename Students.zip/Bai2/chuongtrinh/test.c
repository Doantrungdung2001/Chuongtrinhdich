#include <stdio.h>
#include "abc.h"
#define $ dola
int $;

int main()
{
    abc();
    $ = 100;    
    printf("%d", $);

    return 0;
}

